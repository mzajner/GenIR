#!/bin/bash
echo "Lancement de l'entra�nement avec param�tres standard..."

accelerate launch --config_file=configs/accelerator_config.yaml tangoflux/train.py --checkpointing_steps="best" --save_every=5 --config=configs/tangoflux_config.yaml
